// Во время разработки:
const CALENDAR_DATA_URL = '.files/calendar.json';
// export default CALENDAR_DATA_URL;


// На проде WordPress поменять на корректный путь:
/// export default '/wp-json/custom/v1/events';
